function X = rocholForeSub(ch, Y);

% ROCHOLFORESUB Foreward substitute the representation of the rank one Cholesky.
%
% X = rocholForeSub(ch, Y);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sat Jun 12 13:39:30 2004
% ROCHOL toolbox version 0.1






X = zeros(size(Y));
t = zeros(1, size(Y, 2));
X(1, :) = Y(1, :)/ch.s(1);
for i = 2:ch.n
  if i == 2
    t = Y(1, :)*ch.u(1);
  else
    t = t + ch.s(i-1)*ch.u(i-1)*X(i-1, :);
  end
  X(i, :) = (Y(i, :)-ch.v(i)*t)/ch.s(i);
end

