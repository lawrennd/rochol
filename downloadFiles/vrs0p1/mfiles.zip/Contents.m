% ROCHOL toolbox
% Version 0.1 Saturday, June 12, 2004 at 14:42:24
% Copyright (c) 2004 Neil D. Lawrence
% $Revision: 1.3 1.0 $
% 
% ROCHOLBACKSUB Backsubstitute the representation of the rank one Cholesky.
% ROCHOLEXTRACT Extract the lower triangular matrix from the Cholesky structure.
% ROCHOLFACTORISE Rank one Cholesky factorise.
% ROCHOLFORESUB Foreward substitute the representation of the rank one Cholesky.
% ROCHOLMULTIPLY Multiply by the rank one Cholesky.
% ROCHOLTRANSMULTIPLY Multiply by the transposed version of the rank one Cholesky.
% ROCHOLHFACTORISE Rank one Cholesky factorise.
