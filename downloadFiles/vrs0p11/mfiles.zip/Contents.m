% ROCHOL toolbox
% Version 0.11 Thursday, June 17, 2004 at 15:59:53
% Copyright (c) 2004 Neil D. Lawrence
% $Revision: 1.3 1.0 $
% 
% ROCHOLBACKSUB Backsubstitute the representation of the rank one Cholesky.
% ROCHOLEXTRACT Extract the lower triangular matrix from the Cholesky structure.
% ROCHOLFACTORISE Rank one Cholesky factorise.
% ROCHOLFORESUB Foreward substitute the representation of the rank one Cholesky.
% ROCHOLMULTIPLY Multiply by the rank one Cholesky.
% ROCHOLTRANSMULTIPLY Multiply by the transposed version of the rank one Cholesky.
% ROCHOLHFACTORISE Rank one Cholesky factorise.
