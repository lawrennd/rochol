function L = rocholExtract(ch)

% ROCHOLEXTRACT Extract the lower triangular matrix from the Cholesky structure.
%
% L = rocholExtract(ch)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sat Jun 12 13:39:30 2004
% ROCHOL toolbox version 0.11





L = diag(ch.s);
for j = 1:ch.n
  for i = j+1:ch.n
    L(i, j) = ch.v(i)*ch.s(j)*ch.u(j);
  end
end
